import {Headers,Http,RequestOptions} from "@angular/http";
//import {HttpDataService} from "d"
import{Injectable} from "@angular/core";
import * as $ from "jquery";

export class ModalDailog{

}